With WinAVR version 20100110 or older, please use libusb_0.1.12.1.
